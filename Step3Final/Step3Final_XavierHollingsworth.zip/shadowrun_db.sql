/* Name: Xavier Hollingsworth
** Date: 7/11/18
** File name: shadowrun_db.sql
** Source(s): bsg_db.sql and insert statments from the sql funtion in phpmyadmin
** Comments: I am getting an error for "Foreign key constraint is incorrectly formed"
**  I am going to have to do more research to figure out why I am getting this error.
**
**
*/

--
-- Table structure for table `shadowrun_characters`
--
DROP TABLE IF EXISTS `shadowrun_characters`;
CREATE TABLE `shadowrun_characters` (
  `character_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `leader` int(11) NOT NULL,
  `race_id` int(11) NOT NULL,
  `faction_id` int(11) NOT NULL,
  `weapon_id` int(11) NOT NULL,
  `magic_id` int(11) NOT NULL,
  `tech_id` int(11) NOT NULL,
  PRIMARY KEY (`character_id`),
  CONSTRAINT `shadowrun_characters_ibfk_1` FOREIGN KEY (`race_id`) REFERENCES `shadowrun_race` (`id`),
  CONSTRAINT `shadowrun_characters_ibfk_2` FOREIGN KEY (`faction_id`) REFERENCES `shadowrun_factions` (`id`),
  CONSTRAINT `shadowrun_characters_ibfk_3` FOREIGN KEY (`weapon_id`) REFERENCES `shadowrun_weapons` (`id`),
  CONSTRAINT `shadowrun_characters_ibfk_4` FOREIGN KEY (`magic_id`) REFERENCES `shadowrun_magic` (`id`),
  CONSTRAINT `shadowrun_characters_ibfk_5` FOREIGN KEY (`tech_id`) REFERENCES `shadowrun_tech` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `shadowrun_characters`
--
DROP TABLE IF EXISTS `shadowrun_race`;
CREATE TABLE `shadowrun_race` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `special_ability` varchar(255) NOT NULL,
  `essence` int(11) NOT NULL,
  `health` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `shadowrun_factions`
--
DROP TABLE IF EXISTS `shadowrun_factions`;
CREATE TABLE `shadowrun_factions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `goal` varchar(255) NOT NULL,
  `leader_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shadowrun_factions_ibfk_1` FOREIGN KEY (`leader_id`) REFERENCES `shadowrun_characters`(`character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `shadowrun_weapons`
--
DROP TABLE IF EXISTS `shadowrun_weapons`;
CREATE TABLE `shadowrun_weapons` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`name` varchar(255) DEFAULT NOT NULL,
`damage` int(11) DEFAULT NOT NULL,
`range` varchar(255) DEFAULT NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table 'shadowrun_tech'
--
DROP TABLE IF EXISTS `shadowrun_tech`
CREATE TABLE `shadowrun_tech` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`name` varchar(255) NOT NULL,
`essence_possession` int(11) NOT NULL,
`effect` varchar (255) NOT NULL,
PRIMARY KEY (`id`),
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Table structure for table `shadowrun_magic`
--
DROP TABLE IF EXISTS `shadowrun_magic`
CREATE TABLE `shadowrun_magic` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`name` varchar(255) NOT NULL,
`essence_usage` int(11) NOT NULL,
`effect` varchar (255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
--Testing
--
LOCK TABLES `shadowrun_characters` WRITE;
INSERT INTO `shadowrun_characters` VALUES
(1,`Luscus`, 0, 1, 1, 1, 1, 2),
(2,`Leonidas`, 1, 2, 2, 5, 2, 1),
(3,`Xander`, 0, 3, 3, 4, 3, 4),
(4, `Xerxes`, 1, 4, 4, 3, 4, 3),
(5, `Leonidas`, 0, 2, 2, 3, 2, 1),
(6, `Trinity`, 1, 1, 1, 2, 1, 2),
(7, `Libra`, 0, 4, 4, 5, 4, 3),
(8, `Theocles`, 1, 3, 3, 6, 3, 4);
UNLOCK TABLES;


LOCK TABLES `shadowrun_race` WRITE;
INSERT INTO `shadowrun_race` VALUES
(1, `Human`, `No Essence Usage with Technology`, 10, 175),
(2, `Elf`, `Regenerative Health`, 12, 125),
(3, `Dwarf`, `Sucks Enemy Essence when Nearby`, 8, 190),
(4, `Troll`, `Reduced Damage While Taking Damage`, 7, 250);
UNLOCK TABLES;


LOCK TABLES `shadowrun_factions` WRITE;
INSERT INTO `shadowrun_factions` VALUES
(1, `Red`, `Lineage`, `Freedoom`, 1),
(2, `Blue`, `RNA Global`, `Control Over Staff`, 5),
(3, `Green`, `The ORK`, `Conquer the Homeland`, 7),
(4, `Orange`, `The Ziggurat`, `Destroy the Staff`, 8);
UNLOCK TABLES;


LOCK TABLES `shadowrun_weapons` WRITE;
INSERT INTO `shadowrun_weapons` VALUES
(1, `Pistol`, 10, `Medium`),
(2, `Sword`, 25, `Close`),
(3, `SMG`, 3, `Medium`),
(4, `Shotgun`, 50, `Close`),
(5, `Rifle`, 15, `Long`),
(6, `SniperRifle`, 33, `Very Long`);
UNLOCK TABLES;


LOCK TABLES `shadowrun_tech` WRITE;
INSERT INTO `shadowrun_tech` VALUES
(1, `Teleport`, 3, `Teleports User In Selected Direction`),
(2, `Smart Lock`, 3, `Enhanced Aim`),
(3, `Glider`, 3, `Glider Used to Glide Through Air`),
(4, `Enhanced Vision`, 4, `See Enemeies Through Walls`);
UNLOCK TABLES;


LOCK TABLES `shadowrun_magic` WRITE;
INSERT INTO `shadowrun_magic` VALUES
(1, `Strangle`, 2, `Prevents Opponent from Moving`),
(2, `Resurrect`, 5, `Resurrects Team Members in Vicinity`),
(3,`Minion`, 6, `Summons a Powerful Minion`),
(4, `Tree of Life`, 4, `Regenerates Health for Nearby Characters`);
UNLOCK TABLES;
