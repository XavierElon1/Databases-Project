/*Add Character*/
INSERT INTO `shadowrun_characters` (`name`,`leader`,`race_id`,`faction_id`,`weapon_id`, `magic_id`, `tech_id`) VALUES ([nameInput], [leaderInput], [raceInput],[factionInput],[weaponInput], [magicInput], [techInput]);

/*Add Race*/
INSERT INTO `shadowrun_race` (`name`, `special_ability`,`essence`, `health`) VALUES ([nameInput], [specialAbilityInput], [essenceInput], [healthInput]);

/*Add Faction*/
INSERT INTO `shadowrun_factions` (`color`, `name`,`goal`, `leader_id`) VALUES ([colorInput], [nameInput], [goalInput], [leaderInput]);

/*Add Weapon*/
INSERT INTO `shadowrun_weapons` (`name`, `damage`, `range`) VALUES ([nameInput], [damageInput], [rangeInput]);

/*Add Tech*/
INSERT INTO `shadowrun_tech` (`name`, `essence_possession`,`effect`) VALUES ([nameInput], [essencePossessionInput], [effectInput]);

/*Add Magic*/
INSERT INTO `shadowrun_magic` (`name`, `essence_usage`,`effect`) VALUES ([nameInput], [essenceUsageInput], [effectInput]);


/*Update Character*/
UPDATE `shadowrun_characters` SET `name` = [nameInput],`leader` = [leaderInput],`race_id` = [raceInput] ,`faction_id` = [factionInput],`weapon_id` = [weaponInput], `magic_id` = [magicInput], `tech_id` = [techInput];

/*Update Race*/
UPDATE `shadowrun_race` SET `name`=[nameInput], `special_ability`=[specialAbilityInput],`essence`=[essenceInput], `health` = [healthInput];

/*Update Faction*/
UPDATE `shadowrun_factions` SET `color`=[colorInput], `name`=[nameInput], `goal`=[goalInput],`leader_id`=[leaderInput];

/*Update Weapon*/
UPDATE `shadowrun_weapons` SET `name`=[nameInput], `damage`=[damageInput],`range`=[rangeInput];

/*Update Tech*/
UPDATE `shadowrun_tech` SET `name`=[nameInput], `essence_possession`=[essencePossessionInput],`effect`=[effectInput];

/*Update Magic*/
UPDATE `shadowrun_magic` SET `name`=[nameInput], `essence_usage`=[essenceUsageInput],`effect`=[effectInput];


/*Delete Character*/
DELETE FROM `shadowrun_characters` WHERE `name`=[nameInput];

/*Delete Race*/
DELETE FROM `shadowrun_race` WHERE `name`=[nameInput];

/*Delete Faction*/
DELETE FROM `shadowrun_faction` WHERE `name`=[nameInput];

/*Delete Weapon*/
DELETE FROM `shadowrun_weapons` WHERE `name`=[nameInput];

/*Delete Tech*/
DELETE FROM `shadowrun_tech` WHERE `name`=[nameInput];

/*Delete Magic*/
DELETE FROM `shadowrun_magic` WHERE `name`=[nameInput];


/*Select Race*/
SELECT * FROM `shadowrun_characters` WHERE `race_id` = [raceInput];

/* Select Faction*/
SELECT * FROM `shadowrun_characters` WHERE `faction_id` = [factionInput];

/*Select Weapon*/
SELECT * FROM `shadowrun_characters` WHERE `weapon_id` = [weaponInput];

/*Select Tech*/
SELECT * FROM `shadowrun_characters` WHERE `tech_id` = [techInput];

/*Select Magic*/
SELECT * FROM `shadowrun_characters` WHERE `magic_id` = [magicInput];

/*Select Leader*/
SELECT * FROM `shadowrun_factions` WHERE 'leader_id' = [leaderInput];
